package com.lti.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.dao.CustomerDao;
import com.lti.entity.Customer;

@WebServlet("/RegServlet")
public class RegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public RegServlet() {
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			Customer cust=new Customer();
			cust.setName(request.getParameter("name"));
			cust.setEmail(request.getParameter("email"));
			cust.setPassword(request.getParameter("password"));
			cust.setCity(request.getParameter("city"));
			
			CustomerDao dao = new CustomerDao();
			dao.add(cust);
			
			response.sendRedirect("Confirmation.html");
	}

}
