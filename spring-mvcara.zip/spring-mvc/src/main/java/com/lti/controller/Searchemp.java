package com.lti.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.dao.AccountDao;
import com.lti.dao.Requestmapping;
import com.lti.entity.Account;

@Controller
public class Searchemp {
	
	@Autowired
	private AccountDao dao;
	
	@RequestMapping("/Searchemp.lti")
	public String search(@RequestParam("accid ") int empid,Map<String, Object> model)
	{
		Account acc = dao.fetchById(empid);
		model.put("accountData", acc);
		return "searchAccResult.jsp";
		

	
		
	}

}
