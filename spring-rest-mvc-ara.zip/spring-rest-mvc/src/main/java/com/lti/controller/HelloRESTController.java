package com.lti.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloRESTController {
	
	//important to mention which method here in restful web service
	@GetMapping("/hello.lti")
	public @ResponseBody String hello()
	{
		return "{\"message\" : \"welcome to spring rest\"}"; //Not a file name, it is a response so write as annotation in the public method
		
	}

}
