package com.lti.ui;

import com.lti.dao.CustomerDao;
import com.lti.entity.Customer;

public class Index {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c=new Customer();
		c.setName("Tejas");
		c.setEmail("Tejas.Ta@lntinfotech.com");
		c.setCity("Delhi");
		CustomerDao dao=new CustomerDao();
		dao.add(c);

	}

}
