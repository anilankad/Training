package com.lti.test;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;

import com.lti.dao.CustomerDao;
import com.lti.entity.Customer;

public class CustomerUi {

	//public static void main(String[] args) {
		@Test
		public void testAdd(){
		Customer c=new Customer();
		
		c.setName("Hiral");
		c.setEmail("Hiral@gmail.com");
		c.setCity("Mumbai");
		c.setPassword("hiral");
		CustomerDao dao=new CustomerDao();
		dao.add(c);
		
		
	}
@Test
public void testFetchById()
{
	CustomerDao dao=new CustomerDao();
	Customer c=dao.fetchById(1);
	assertNotNull(c);
	System.out.println(c.getName());
	System.out.println(c.getEmail());
	System.out.println(c.getCity());
	System.out.print(c.getPassword());
}

@Test
public void testMergeById()
{
	CustomerDao dao=new CustomerDao();
	Customer c=dao.fetchById(1);
	c.setCity("Chennai");
	dao.update(c);
	assertNotNull(c);
	
}

@Test
public void testbycity()
{
	CustomerDao dao=new CustomerDao();
	List<Customer> list=dao.fetchByCity("Mumbai");
	assertNotNull(list);
	
	//try using lambda for also
	
	for(Customer c:list)
	{
	System.out.println(c.getName());
	System.out.println(c.getEmail());
	System.out.println(c.getCity());
	System.out.print(c.getPassword());
	}
}

}
