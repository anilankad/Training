package com.lti.test;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.junit.Test;

import com.lti.dao.GenericDao;
import com.lti.dao.UserDao;
import com.lti.entity.Address;
import com.lti.entity.Passport;
import com.lti.entity.User;


public class UserAddressTest {
	
	Scanner sc = new Scanner(System.in);
	
	@Test
	public void addNewUser() {
		User u = new User();
		GenericDao gd = new GenericDao();
		
		System.out.println("Enter name: ");
		String name = sc.next();
		u.setName(name);
		
		System.out.println("Enter email: ");
		String email = sc.next();
		u.setEmail(email);
		
		gd.save(u);
	}
	
	@Test
	public void addAddressForAnExistingUser() {
		Address a = new Address();
		
		System.out.println("Enter street: ");
		String street = sc.next();
		a.setStreet(street);
		
		System.out.println("Enter city: ");
		String city = sc.next();
		a.setCity(city);
		
		System.out.println("Enter pincode: ");
		int pincode = sc.nextInt();
		a.setPincode(pincode);
		
		System.out.println("Enter state: ");
		String state = sc.next();
		a.setState(state);
		
		GenericDao gd = new GenericDao();
		User u = gd.fetchById(User.class, 81);
		a.setUser(u);
		gd.save(a);
		
	}

	@Test
	public void addUserAndAddressTogether() {
		User u=new User();
		
		System.out.println("Enter name: ");
		String name = sc.next();
		u.setName(name);
		
		System.out.println("Enter email: ");
		String email = sc.next();
		u.setEmail(email);
		
		Address a = new Address();
		
		System.out.println("Enter street: ");
		String street = sc.next();
		a.setStreet(street);
		
		System.out.println("Enter city: ");
		String city = sc.next();
		a.setCity(city);
		
		System.out.println("Enter pincode: ");
		int pincode = sc.nextInt();
		a.setPincode(pincode);
		
		System.out.println("Enter state: ");
		String state = sc.next();
		a.setState(state);
		
		u.setAddress(a);
		a.setUser(u);
		
		GenericDao gd = new GenericDao();
		gd.save(u);
		
	}
	
	
	
	@Test
	public void fetchUserByCity()
	{
		UserDao dao=new UserDao();
		List<User> users=dao.fetchByCity("thane");
		for(User user: users)
		{
			System.out.println(user.getName());
			System.out.println(user.getEmail());
		}
	}
	
	
	
}
