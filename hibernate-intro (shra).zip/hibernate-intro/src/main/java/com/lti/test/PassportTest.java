package com.lti.test;

import java.time.LocalDate;
import java.util.List;

import org.junit.Test;

import com.lti.dao.GenericDao;
import com.lti.dao.UserDao;
import com.lti.entity.Passport;
import com.lti.entity.User;

public class PassportTest {
	@Test
	public void addUser() {
	 User u=new User();
	 
	 //u.setId(1);
	 u.setName("Mrunal");
	 u.setEmail("Mrunal@lntinfotech.com");
	 
	 GenericDao gd=new GenericDao();
	 
	 gd.save(u);
	}
	@Test
	public void addPassportForAnExisitingUser() {
	 Passport p = new Passport();
	 p.setName("Mrunal");
	 p.setNationality("India");
	 
	// p.setExpdate(LocalDate.of(1998, 8 , 2));
	 p.setExp_date(LocalDate.of(1998, 8,2));
	 
	 
	 GenericDao gd= new GenericDao();
	 User u = new User();
	 u= (User) gd.fetchById(User.class, 86);
	 p.setUser(u);
	 gd.save(p);
	}

	@Test
	public void addUserAndPassportTogether() {
	 User user=new User();
	 user.setName("Jay");
	 user.setEmail("jay@veeru.com");
	 
	 Passport p = new Passport();
	 p.setName("Mrunal");
	 p.setExp_date(LocalDate.of(1998, 8 , 2));
	 p.setNationality("India");
	 
	 user.setPassport(p);
	 p.setUser(user);
	 
	 GenericDao gd = new GenericDao();
	 gd.save(user);
	 
	}

	@Test
	public void fetchByPassportExpiry() {
	 UserDao usd = new UserDao();
	 List<User> result = usd.fetchByExpiryDate(LocalDate.of(2001,01,01));
	 for(User user:result) {
	  System.out.println("---------------Expired Passport ----------------------------");
	  System.out.println("Name: "+user.getName());
	  System.out.println("Email: "+user.getEmail());
	}
	}
	
	@Test
	public void fetchByUserInfo() {
		UserDao usd = new UserDao();
		List<Object[]> result = usd.fetchUserInfo();
		 for (Object o[]: result){
			 	System.out.println("--------------------USER INFO--------------------");
		      System.out.println("Name: "+o[0]);
		      System.out.println("City: "+o[1]);
		      System.out.println("Country: "+o[2]);
	    }
	}

	
}
