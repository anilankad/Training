package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.lti.entity.Customer;

public class CustomerDao {
	public void add(Customer customer)
		{
		EntityManagerFactory emf=null;
		EntityManager em=null;
			try
			{
				//Step1. Create/'Obtain EntityManagerFactory object
				//During this step,META-INF/ persistence.xml file will be read
				//Loading the entire configuration in memory...oracleTest is in persistence.xnml ..so we are loading that configuration
				emf=Persistence.createEntityManagerFactory("oracleTest");
				
				//Step2. Create /Obtain EntityManager object
				//This step is similar to opening a new connection
				//in regular JDBC code
				em=emf.createEntityManager();
				
				//Step 3. Start/Participate in a Transaction
				//ACID principle is must ie. transaction from proj point of view is imp 
				//Here we used to do begin() and commit
				// In JDBC it does auto commit
				//We cannot use autocommit in real proj as we cannot rollback from autocommit
				EntityTransaction tx=em.getTransaction(); 
				tx.begin();
			//Now we can insert/update/delete/select operations
			em.persist(customer);//persist method generates insert query
			tx.commit();
			}
			//below code should be in finally block
			finally {
			emf.close();
			em.close();
			}
		}
		public Customer fetchById(int id){
			EntityManagerFactory emf=null;
			EntityManager em=null;
			try {
				emf=Persistence.createEntityManagerFactory("oracleTest");
				em=emf.createEntityManager();
			//find method generates select query
			//first parameter is class where table is made
			//second parameter is id ie. fetching data based on id
				Customer c=em.find(Customer.class,id);
				return c;
			}
			finally
			{
			em.close();
			emf.close();
			
		
			}
		}
		
		public Customer fetch(String email, String password)
		{
			
			 EntityManagerFactory emf =null;
			 EntityManager em=null;
			try{
			    emf = Persistence.createEntityManagerFactory("oracleTest");
			   em = emf.createEntityManager();
			   EntityTransaction tx = em.getTransaction();
			  tx.begin();
			  //introducing JPQL/HQL
			  // you can only check email like gmail.
			  
			  String query="Select c from Customer c where"
					  +" c.email= :em and c.password= :pwd";
			  Query q = em.createQuery(query);
			  q.setParameter("em", email);
			  q.setParameter("pwd", password);
			 Customer  c=(Customer) q.getSingleResult();
			  return c;
			  }
			  //why single ? because only 1 data should be returned.
			  finally {
			  //below code should be finally block
			  em.close();
			  emf.close();
			  }
		}
		
		
		public List<Customer> fetchByCity(String City)
		{
			 EntityManagerFactory emf = Persistence.createEntityManagerFactory("oracleTest");
			  EntityManager em = emf.createEntityManager();
			  EntityTransaction tx = em.getTransaction();
			  tx.begin();
			  //introducing JPQL/HQL
			  // you can only check email like gmail.
			  String query="Select c from Customer c where"
					  +" c.city= :city";
			  Query q = em.createQuery(query);
			  q.setParameter("city",City);
			  List<Customer> list =q.getResultList();
			   em.close();
			  emf.close();
			  
			  return list;
		}
		public void update(Customer customer)
		{
			EntityManagerFactory emf=null;
			EntityManager em=null;
			try {
				emf=Persistence.createEntityManagerFactory("oracleTest");
				em=emf.createEntityManager();
				EntityTransaction tx=em.getTransaction(); 
				tx.begin();
			
				//Now we can insert/update/delete/select operations
				em.merge(customer);//merge method generates update query
				tx.commit();
			}
			finally {
				//below code should be in finally block
				emf.close();
				em.close();
			}
		}
}

