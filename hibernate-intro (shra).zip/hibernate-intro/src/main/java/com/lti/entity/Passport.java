package com.lti.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="TBL_PASSPORT")

public class Passport {
	@Id
	@GeneratedValue
	private  int pid;
	private String name;
	private LocalDate exp_date;
	private String nationality;
	
	//has-a relationship
			@OneToOne
			@JoinColumn(name="U_ID") //fk
			private User user;
	
	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public LocalDate getExp_date() {
		return exp_date;
	}

	public void setExp_date(LocalDate exp_date) {
		this.exp_date = exp_date;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}


		
}
