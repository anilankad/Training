package com.lti.component;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("carParts4")
public class CarPartsInventoryImpl4 implements CarPartsInventory 
{
	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public void addNewPart(CarPart carPart) 
	{			
		entityManager.persist(carPart);
	}
	
    public List<CarPart>getAvailableParts() 
	{
    	
		String query = "select c from CarPart c";
		Query q = entityManager.createQuery(query);
		return q.getResultList();
	}	
	
}
