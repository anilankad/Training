package com.lti.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.component.CarPart;
import com.lti.component.CarPartsInventory;

public class IoCTest {

	@Test
	public void test()
	{
		// Loading the IoC container of Spring
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		
		CarPartsInventory cpv = (CarPartsInventory)context.getBean("carParts4");
		CarPart cp = new CarPart();
		cp.setPartNo(555);
		cp.setCarModel("honda");
		cp.setName("headlights");
		cp.setQuantity(25);
		cpv.addNewPart(cp);
	}

	
	
	
}
