package com.lti.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.lti.entity.Customer;

public class CustomerDao {
	
			public void add(Customer customer)
					{
						//Step1.Create/Obtain EntityManagerFactory object
						//During This step,META-INF/persistence.xml file will be read
						EntityManagerFactory emf=
								Persistence.createEntityManagerFactory("oracleTest");
						//Step2.Create/Obtain EntityManager object
						//this is like opening connection
						//in regular JDBC code
						EntityManager em = emf.createEntityManager();
						
						//Step3.Start/Participate in a Transaction
						EntityTransaction tx=em.getTransaction();
						tx.begin();
						
						//Now we can Perform CRUD operations
						em.persist(customer);
						
						tx.commit();
						
						//below code should be in finally block
						emf.close();
						em.close();
						
					}
}
