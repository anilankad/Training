package com.lti.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.component.Calculator;
import com.lti.component.CurrencyConverter;
import com.lti.component.HdfcAtm;
import com.lti.component.HelloWorld;
import com.lti.component.MultiplyandDivide;
import com.lti.component.SpellChecker;
import com.lti.component.TextEditor;

public class IoCTest {
	
	@Test
	public void test()
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-config.xml");
		HelloWorld h=(HelloWorld)context.getBean("hw");
		System.out.println(h.sayHello("ARA"));
	}
 
	@Test
	public void cal()
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-config.xml");
		//called methods
		for(int i=0;i<5;i++)
		{
		Calculator h=(Calculator)context.getBean("cal");
		System.out.print(h.add(100,30)+" ");
		System.out.println(h.sub(100,30));
	}}
	
	
	@Test
	public void cur()
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-config.xml");
		CurrencyConverter cur=(CurrencyConverter)context.getBean("cc");
		System.out.println(cur.convertDollarsToRupees(100));
	}
	@Test
	public void mul()
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-config.xml");
		MultiplyandDivide mull=(MultiplyandDivide)context.getBean("dm");
		System.out.println(mull.divide(5, 1));
		System.out.println(mull.multiply(50,1));
	}
	@Test
	public void splck()
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-config.xml");
		TextEditor te=(TextEditor)context.getBean("te");
		te.load("Done.txt");
			}
	
	@Test
	public void hici()
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-config.xml");
		HdfcAtm te=(HdfcAtm)context.getBean("hd");
		te.withdraw(1000);
		
	}
}
