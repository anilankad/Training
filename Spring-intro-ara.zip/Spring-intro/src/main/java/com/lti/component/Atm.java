package com.lti.component;


public interface Atm {
			public void withdraw(double amount);
}
