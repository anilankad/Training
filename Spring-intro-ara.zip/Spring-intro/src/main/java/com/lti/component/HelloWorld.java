package com.lti.component;

public class HelloWorld {
	
	public String sayHello(String name) {
		return "hello "+ name;
	}

}
