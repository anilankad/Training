package com.lti.component;

import org.springframework.stereotype.Component;

@Component("dm")
public class MultiplyandDivide {

	
	public int multiply(int a , int b) {
		return a*b;
	} 
	
	public int divide(int a , int b) {
		return a/b;
	} 
}
