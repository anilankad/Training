package com.lti.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("hd")
public class HdfcAtm implements Atm {

	@Autowired // DI this creates object for us and here we can call any method
	private IciciBank ib; 
	
	public void withdraw (double amount)
	{
		
		System.out.println("Withdrawn");
		ib.debit(amount);
	}
	
	
	
	
}
