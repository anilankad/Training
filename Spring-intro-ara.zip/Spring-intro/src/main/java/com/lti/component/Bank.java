package com.lti.component;

public interface Bank {
	
	
	public void debit(double amount); 
		
	
	
}
