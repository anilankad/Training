package com.lti.component;

public class Calculator {
	
	/*public Calculator()
	{
		System.out.println("Calculator constr is called");
	}*/

	public int add(int a , int b) {
		return a+b;
	} 
	
	public int sub(int a , int b) {
		return a-b;
	} 
}
