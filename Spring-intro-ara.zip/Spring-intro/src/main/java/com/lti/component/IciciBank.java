package com.lti.component;

import org.springframework.stereotype.Component;

@Component("ib")
public class IciciBank implements Bank {

	
	public void debit (double amount) {
		
		System.out.println("amount debited is "+amount);

	}


}
